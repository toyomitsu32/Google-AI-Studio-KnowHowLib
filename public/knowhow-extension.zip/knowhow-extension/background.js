/**
 * background.js - Service Worker
 * ノウハウ図書館インポーター拡張機能のバックグラウンド処理
 */

// article-importer ページを開くメッセージを受け取る
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'OPEN_IMPORTER') {
    chrome.tabs.create({
      url: chrome.runtime.getURL('article-importer.html'),
    });
    sendResponse({ success: true });
  }

  // content script へのリレー（ライブラリページへのデータ送信）
  if (message.type === 'INJECT_ARTICLE') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab?.id) {
        sendResponse({ success: false, error: 'アクティブなタブが見つかりません' });
        return;
      }
      chrome.tabs.sendMessage(tab.id, message, (response) => {
        sendResponse(response || { success: false, error: '応答なし' });
      });
    });
    return true; // 非同期レスポンスのため
  }

  return true;
});
