/**
 * popup.js - ポップアップUI のロジック
 */

const statusEl = document.getElementById('status');

function setStatus(msg, type = '') {
  statusEl.textContent = msg;
  statusEl.className = 'status' + (type ? ' ' + type : '');
}

// 記事インポーターページを開くボタン
document.getElementById('btn-open-importer').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'OPEN_IMPORTER' }, (response) => {
    if (response?.success) {
      window.close();
    } else {
      setStatus('インポーターを開けませんでした', 'error');
    }
  });
});

// クリップボードから直接注入するボタン
document.getElementById('btn-inject-clipboard').addEventListener('click', async () => {
  setStatus('クリップボードを読み込み中...');
  try {
    const text = await navigator.clipboard.readText();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      setStatus('クリップボードにJSONデータが見つかりません。\nノウハウ出版社でコピーしてから再試行してください。', 'error');
      return;
    }

    if (!data || data.source !== 'knowhow-interviewer') {
      setStatus('ノウハウ出版社のデータではありません', 'error');
      return;
    }

    // アクティブタブのコンテンツスクリプトにデータを送信
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      setStatus('アクティブなタブが見つかりません', 'error');
      return;
    }

    chrome.tabs.sendMessage(tab.id, { type: 'INJECT_ARTICLE', data }, (response) => {
      if (chrome.runtime.lastError) {
        setStatus('ノウハウ図書館の投稿ページを開いてから再試行してください', 'error');
        return;
      }
      if (response?.success) {
        setStatus('✅ 記事データを注入しました！', 'success');
      } else {
        setStatus('注入に失敗しました: ' + (response?.error || '不明なエラー'), 'error');
      }
    });
  } catch (e) {
    setStatus('クリップボードの読み取りに失敗しました: ' + e.message, 'error');
  }
});
