/**
 * library-bridge.js - Content Script
 * ノウハウ図書館の投稿ページにデータを注入するコンテンツスクリプト
 *
 * 受け取るメッセージ形式（PublishStep.tsx の handleCopyForExtension が生成）:
 * {
 *   type: 'INJECT_ARTICLE',
 *   data: {
 *     source: 'knowhow-interviewer',
 *     version: '1.0',
 *     title: string,
 *     summary: string,
 *     category: string,
 *     tags: string[],
 *     thumbnail: null | string,
 *     sections: Array<{ heading: string, body: string, image: null, inlineImages: [] }>
 *   }
 * }
 */

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type !== 'INJECT_ARTICLE') return;

  const data = message.data;
  if (!data || data.source !== 'knowhow-interviewer') {
    sendResponse({ success: false, error: '無効なデータ形式です' });
    return;
  }

  try {
    injectArticleData(data);
    sendResponse({ success: true });
  } catch (e) {
    sendResponse({ success: false, error: String(e) });
  }
});

/**
 * 記事データをページのフォームに注入する
 */
function injectArticleData(data) {
  // タイトル入力欄を探して設定
  const titleInput = document.querySelector('input[placeholder*="タイトル"], input[name="title"], [data-field="title"] input');
  if (titleInput) {
    setInputValue(titleInput, data.title);
  }

  // サマリー入力欄を探して設定
  const summaryInput = document.querySelector('textarea[placeholder*="要約"], textarea[name="summary"], [data-field="summary"] textarea');
  if (summaryInput) {
    setInputValue(summaryInput, data.summary);
  }

  // カテゴリ選択を試みる
  if (data.category) {
    const categorySelect = document.querySelector('select[name="category"], [data-field="category"] select');
    if (categorySelect) {
      const options = Array.from(categorySelect.options);
      const match = options.find(opt => opt.text.includes(data.category) || opt.value.includes(data.category));
      if (match) {
        categorySelect.value = match.value;
        categorySelect.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }
  }

  // タグを設定
  if (data.tags && data.tags.length > 0) {
    const tagInput = document.querySelector('input[placeholder*="タグ"], [data-field="tags"] input');
    if (tagInput) {
      data.tags.forEach(tag => {
        setInputValue(tagInput, tag);
        tagInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
        tagInput.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', bubbles: true }));
      });
    }
  }

  // 本文（Lexicalエディタ）への注入はlexical-writer.jsが担当
  // セクションデータをカスタムイベントで渡す
  document.dispatchEvent(new CustomEvent('knowhow-importer:inject-sections', {
    detail: { sections: data.sections }
  }));
}

/**
 * Reactの制御下にあるinput/textareaに値をセットする
 */
function setInputValue(element, value) {
  const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
    element.tagName === 'INPUT' ? window.HTMLInputElement.prototype : window.HTMLTextAreaElement.prototype,
    'value'
  )?.set;

  if (nativeInputValueSetter) {
    nativeInputValueSetter.call(element, value);
  } else {
    element.value = value;
  }

  element.dispatchEvent(new Event('input', { bubbles: true }));
  element.dispatchEvent(new Event('change', { bubbles: true }));
}
