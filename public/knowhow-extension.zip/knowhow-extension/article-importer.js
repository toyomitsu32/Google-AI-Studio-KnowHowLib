/**
 * article-importer.js
 * ノウハウ図書館インポーター - メインロジック
 *
 * クリップボードから記事データを読み込み、ステップUIで確認・編集後、
 * ノウハウ図書館の投稿ページに自動入稿する。
 */

const LIBRARY_NEW_POST_URL = 'https://library.libecity.com/articles/new';

// アプリケーション状態
const state = {
  currentStep: 1,
  articleData: null,   // クリップボードから読み込んだ生データ
  meta: {              // ステップ2で編集するメタ情報
    title: '',
    summary: '',
    category: '',
    tags: [],
  },
  images: [],          // ステップ3で選択した画像ファイル
  imageAssignments: [], // [thumbnail, section0, section1, ...]
};

// ─────────────────────────────────────────────
// ステップナビゲーション
// ─────────────────────────────────────────────

function goToStep(step) {
  state.currentStep = step;
  document.querySelectorAll('.step-content').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.step-btn').forEach(el => {
    const s = parseInt(el.dataset.step);
    el.classList.remove('active', 'done');
    if (s === step) el.classList.add('active');
    else if (s < step) el.classList.add('done');
  });
  document.getElementById(`step-${step}`).classList.add('active');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

document.querySelectorAll('.step-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const step = parseInt(btn.dataset.step);
    if (step < state.currentStep || (step === state.currentStep + 1 && state.articleData)) {
      goToStep(step);
    }
  });
});

// ─────────────────────────────────────────────
// ステップ1: クリップボードから読み込み
// ─────────────────────────────────────────────

document.getElementById('btn-load-clipboard').addEventListener('click', async () => {
  const statusEl = document.getElementById('load-status');
  statusEl.innerHTML = '<div class="alert alert-info">クリップボードを読み込み中...</div>';

  try {
    const text = await navigator.clipboard.readText();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      statusEl.innerHTML = '<div class="alert alert-error">クリップボードにJSONデータが見つかりません。<br>ノウハウ出版社の「入稿」ステップでコピーしてから再試行してください。</div>';
      return;
    }

    if (!data || data.source !== 'knowhow-interviewer') {
      statusEl.innerHTML = '<div class="alert alert-error">ノウハウ出版社のデータではありません。<br>正しいデータをコピーしてから再試行してください。</div>';
      return;
    }

    state.articleData = data;
    // メタ情報を初期化
    state.meta.title = data.title || '';
    state.meta.summary = data.summary || '';
    state.meta.category = data.category || '';
    state.meta.tags = [...(data.tags || [])];

    statusEl.innerHTML = '<div class="alert alert-success">✅ データを読み込みました！</div>';
    renderPreview(data);
    document.getElementById('preview-card').style.display = 'block';

  } catch (e) {
    statusEl.innerHTML = `<div class="alert alert-error">クリップボードの読み取りに失敗しました。<br>${e.message}</div>`;
  }
});

function renderPreview(data) {
  const el = document.getElementById('preview-content');
  const sectionCount = data.sections?.length || 0;
  el.innerHTML = `
    <div style="font-size:13px;color:#564337;line-height:1.8;">
      <strong style="color:#1b1c1c;font-size:15px;">${escHtml(data.title)}</strong><br>
      <span style="color:#78716c;">カテゴリ: ${escHtml(data.category)}</span><br>
      <span style="color:#78716c;">タグ: ${(data.tags || []).map(t => `<span style="background:#fff0e0;border:1px solid #e67e22;border-radius:12px;padding:1px 8px;font-size:11px;color:#502600;">${escHtml(t)}</span>`).join(' ')}</span><br>
      <span style="color:#78716c;">セクション数: ${sectionCount}</span>
    </div>
    <div style="margin-top:10px;">
      ${(data.sections || []).map((s, i) => `
        <div style="padding:6px 10px;background:#f6f3f2;border-radius:6px;margin-bottom:6px;font-size:12px;color:#564337;">
          <strong>${i + 1}. ${escHtml(s.heading)}</strong>
          <div style="color:#78716c;margin-top:2px;">${escHtml(s.body.slice(0, 60))}${s.body.length > 60 ? '...' : ''}</div>
        </div>
      `).join('')}
    </div>
  `;
}

document.getElementById('btn-step1-next').addEventListener('click', () => {
  if (!state.articleData) return;
  populateStep2();
  goToStep(2);
});

// ─────────────────────────────────────────────
// ステップ2: メタ情報の確認・編集
// ─────────────────────────────────────────────

function populateStep2() {
  document.getElementById('meta-title').value = state.meta.title;
  document.getElementById('meta-summary').value = state.meta.summary;
  document.getElementById('meta-category').value = state.meta.category;
  renderTags();
  updateSummaryCount();
}

function renderTags() {
  const container = document.getElementById('tags-container');
  container.innerHTML = state.meta.tags.map((tag, i) => `
    <span class="tag">
      ${escHtml(tag)}
      <span class="tag-remove" data-index="${i}">×</span>
    </span>
  `).join('');
  container.querySelectorAll('.tag-remove').forEach(btn => {
    btn.addEventListener('click', () => {
      state.meta.tags.splice(parseInt(btn.dataset.index), 1);
      renderTags();
    });
  });
}

function updateSummaryCount() {
  const val = document.getElementById('meta-summary').value;
  document.getElementById('summary-count').textContent = val.length;
}

document.getElementById('meta-title').addEventListener('input', e => { state.meta.title = e.target.value; });
document.getElementById('meta-summary').addEventListener('input', e => { state.meta.summary = e.target.value; updateSummaryCount(); });
document.getElementById('meta-category').addEventListener('input', e => { state.meta.category = e.target.value; });

document.getElementById('tag-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') addTag();
});
document.getElementById('btn-add-tag').addEventListener('click', addTag);

function addTag() {
  const input = document.getElementById('tag-input');
  const tag = input.value.trim();
  if (tag && !state.meta.tags.includes(tag)) {
    state.meta.tags.push(tag);
    renderTags();
  }
  input.value = '';
}

document.getElementById('btn-step2-back').addEventListener('click', () => goToStep(1));
document.getElementById('btn-step2-next').addEventListener('click', () => {
  populateStep3();
  goToStep(3);
});

// ─────────────────────────────────────────────
// ステップ3: 画像の割り当て
// ─────────────────────────────────────────────

function populateStep3() {
  renderSectionsList();
}

function renderSectionsList() {
  const el = document.getElementById('sections-list');
  const sections = state.articleData?.sections || [];
  if (sections.length === 0) {
    el.innerHTML = '<div class="empty-state"><div class="icon">📝</div><p>セクションがありません</p></div>';
    return;
  }
  el.innerHTML = sections.map((s, i) => `
    <div class="section-item">
      <div class="section-heading">${escHtml(s.heading)}</div>
      <div class="section-body">${escHtml(s.body.slice(0, 150))}${s.body.length > 150 ? '...' : ''}</div>
      <div class="section-image-label">
        🖼️ アイキャッチ: ${state.imageAssignments[i + 1] ? `<strong>${escHtml(state.imageAssignments[i + 1].name)}</strong>` : '<span style="color:#a8a29e;">未割り当て</span>'}
      </div>
    </div>
  `).join('');
}

// 画像選択
const imageDropZone = document.getElementById('image-drop-zone');
const imageInput = document.getElementById('image-input');

imageDropZone.addEventListener('click', () => imageInput.click());
imageInput.addEventListener('change', e => handleImageFiles(Array.from(e.target.files)));

imageDropZone.addEventListener('dragover', e => {
  e.preventDefault();
  imageDropZone.classList.add('drag-over');
});
imageDropZone.addEventListener('dragleave', () => imageDropZone.classList.remove('drag-over'));
imageDropZone.addEventListener('drop', e => {
  e.preventDefault();
  imageDropZone.classList.remove('drag-over');
  const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
  handleImageFiles(files);
});

function handleImageFiles(files) {
  // 画像ファイルを名前順でソート
  files.sort((a, b) => a.name.localeCompare(b.name));
  state.images = files;
  state.imageAssignments = files; // 1枚目=サムネイル, 2枚目以降=セクション
  renderImagePreview();
  renderSectionsList();
}

function renderImagePreview() {
  const grid = document.getElementById('image-preview-grid');
  if (state.images.length === 0) {
    grid.innerHTML = '';
    return;
  }
  grid.innerHTML = state.images.map((file, i) => {
    const url = URL.createObjectURL(file);
    const label = i === 0 ? 'サムネイル' : `セクション${i}`;
    return `
      <div class="image-preview-item ${i === 0 ? 'thumbnail' : ''}">
        <img src="${url}" alt="${escHtml(file.name)}" />
        <div class="image-preview-badge">${label}</div>
      </div>
    `;
  }).join('');
}

document.getElementById('btn-step3-back').addEventListener('click', () => goToStep(2));
document.getElementById('btn-step3-next').addEventListener('click', () => {
  populateStep4();
  goToStep(4);
});

// ─────────────────────────────────────────────
// ステップ4: 寄稿
// ─────────────────────────────────────────────

function populateStep4() {
  const el = document.getElementById('final-summary');
  const sections = state.articleData?.sections || [];
  el.innerHTML = `
    <strong>タイトル:</strong> ${escHtml(state.meta.title)}<br>
    <strong>カテゴリ:</strong> ${escHtml(state.meta.category)}<br>
    <strong>タグ:</strong> ${state.meta.tags.map(t => escHtml(t)).join(', ') || 'なし'}<br>
    <strong>セクション数:</strong> ${sections.length}<br>
    <strong>画像:</strong> ${state.images.length > 0 ? `${state.images.length}枚（サムネイル1枚 + アイキャッチ${state.images.length - 1}枚）` : '未設定'}
  `;
}

document.getElementById('btn-step4-back').addEventListener('click', () => goToStep(3));

document.getElementById('btn-contribute').addEventListener('click', async () => {
  const statusEl = document.getElementById('contribute-status');
  statusEl.innerHTML = '<div class="alert alert-info">ノウハウ図書館の投稿ページを開いています...</div>';

  // 拡張機能用のJSONを構築（PublishStep.tsxと同じ形式）
  const exportData = {
    source: 'knowhow-interviewer',
    version: '1.0',
    title: state.meta.title,
    summary: state.meta.summary.slice(0, 140),
    category: state.meta.category,
    tags: state.meta.tags,
    thumbnail: null,
    sections: state.articleData?.sections || [],
  };

  // クリップボードに書き込む（ノウハウ図書館のコンテンツスクリプトが読み取る）
  try {
    await navigator.clipboard.writeText(JSON.stringify(exportData));
  } catch (e) {
    statusEl.innerHTML = `<div class="alert alert-error">クリップボードへの書き込みに失敗しました: ${e.message}</div>`;
    return;
  }

  // 投稿ページを新しいタブで開く
  const tab = await chrome.tabs.create({ url: LIBRARY_NEW_POST_URL });

  // タブが読み込まれたらコンテンツスクリプトにメッセージを送る
  const listener = (tabId, changeInfo) => {
    if (tabId === tab.id && changeInfo.status === 'complete') {
      chrome.tabs.onUpdated.removeListener(listener);
      setTimeout(() => {
        chrome.tabs.sendMessage(tab.id, { type: 'INJECT_ARTICLE', data: exportData }, (response) => {
          if (response?.success) {
            statusEl.innerHTML = '<div class="alert alert-success">✅ 記事データを注入しました！投稿ページを確認してください。</div>';
          } else {
            statusEl.innerHTML = `<div class="alert alert-error">注入に失敗しました。ページを手動で確認してください。<br>${response?.error || ''}</div>`;
          }
        });
      }, 1500);
    }
  };
  chrome.tabs.onUpdated.addListener(listener);
});

// ─────────────────────────────────────────────
// ユーティリティ
// ─────────────────────────────────────────────

function escHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
