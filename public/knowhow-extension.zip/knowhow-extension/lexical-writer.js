/**
 * lexical-writer.js - Content Script
 * Lexicalエディタ（ノウハウ図書館の本文エディタ）にセクション本文を注入する
 *
 * ノウハウ図書館はLexicalベースのリッチテキストエディタを使用しているため、
 * 単純なinput/textareaへの値セットではなく、
 * Lexicalのエディタ状態を操作する必要がある。
 */

document.addEventListener('knowhow-importer:inject-sections', (event) => {
  const { sections } = event.detail;
  if (!sections || sections.length === 0) return;

  // Lexicalエディタのcontenteditable要素を探す
  const editor = findLexicalEditor();
  if (!editor) {
    console.warn('[ノウハウインポーター] Lexicalエディタが見つかりませんでした');
    return;
  }

  // エディタをクリアして本文を挿入
  injectSectionsToEditor(editor, sections);
});

/**
 * ページ内のLexicalエディタ（contenteditable）を探す
 */
function findLexicalEditor() {
  // Lexicalエディタは data-lexical-editor 属性を持つ contenteditable 要素
  const lexicalEditor = document.querySelector('[data-lexical-editor="true"]');
  if (lexicalEditor) return lexicalEditor;

  // フォールバック: contenteditable の要素を探す
  const contentEditables = document.querySelectorAll('[contenteditable="true"]');
  for (const el of contentEditables) {
    // 本文エディタらしき要素を選択（小さいものは除外）
    const rect = el.getBoundingClientRect();
    if (rect.height > 200) return el;
  }
  return null;
}

/**
 * セクションデータをLexicalエディタに注入する
 * @param {HTMLElement} editor - contenteditable要素
 * @param {Array} sections - セクション配列
 */
function injectSectionsToEditor(editor, sections) {
  // エディタにフォーカスを当てる
  editor.focus();

  // 既存コンテンツを全選択して削除
  document.execCommand('selectAll', false, null);
  document.execCommand('delete', false, null);

  // 各セクションを挿入
  sections.forEach((section, index) => {
    if (index > 0) {
      // セクション間の改行
      document.execCommand('insertParagraph', false, null);
    }

    // 見出しを挿入（## 見出し → H2として挿入）
    if (section.heading) {
      document.execCommand('insertText', false, section.heading);
      document.execCommand('insertParagraph', false, null);
    }

    // 本文を挿入（マークダウンの改行を段落に変換）
    if (section.body) {
      const paragraphs = section.body.split('\n\n').filter(p => p.trim());
      paragraphs.forEach((para, pIndex) => {
        if (pIndex > 0) {
          document.execCommand('insertParagraph', false, null);
        }
        document.execCommand('insertText', false, para.trim());
      });
    }
  });

  // 変更イベントを発火
  editor.dispatchEvent(new Event('input', { bubbles: true }));
  editor.dispatchEvent(new Event('change', { bubbles: true }));
}
